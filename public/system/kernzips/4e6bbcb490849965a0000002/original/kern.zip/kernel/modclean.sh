#!/sbin/sh
busybox rm /system/lib/modules/*
return $?
